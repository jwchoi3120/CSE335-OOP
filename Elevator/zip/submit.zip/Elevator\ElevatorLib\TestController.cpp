#include "pch.h"
#include "TestController.h"


CTestController::CTestController()
{
}


CTestController::~CTestController()
{
}
