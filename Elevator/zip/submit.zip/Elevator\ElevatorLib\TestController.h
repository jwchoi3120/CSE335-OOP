#pragma once
#include "ElevatorController.h"
class CTestController :
    public CElevatorController
{
public:
    CTestController();
    ~CTestController();
};

