
#include "stdafx.h"
#include "Kitchen.h"

const std::wstring CKitchen::ImagesDirectory = L"KitchenLib/images/";
